key:find a machine way to do human stuff 

as it replies in json format lets say i want it to automate keyboard actions on my desktop (i already paired it with uno via UART)so 

it's like it's Sunday i wanna play keyboard midi in fl studio and use that fl studio feature to allow keyboard keys to act as physical midi keys


and i tell it tha the song's progression is 1 4 5 4 1 in f# bpm is likely 120 

and wat it does it creates a python script, using python midi libraries and that python script has the midi chords assigned to it and the agent runs the chord ,the magic happens  so it's not music only but all tasks i assign it in future it shouldn't use the exact workflow but use same strategy, instead of seeking to do human stuff straight it find similar alternative to achieve same goal 

